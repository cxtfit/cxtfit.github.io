Two Well Test Data Analysis

FILE LIST

twowelltest.bas VBA code source file
Fig2.xls        Excel file for Figure 2
Fig4.xls        Excel file for Figure 4
Fig5.xls        Excel file for Figure 5
Fig6.xls        Excel file for Figure 6
 
Note: CXYT, CXYTP, and CXYTPS account for advection only case when E is very small, 

CONTACT
   Guoping Tang
   July 5, 2011
   Environmental Sciences Division
   Oak Ridge National Laboratory
   PO Box 2008
   Oak Ridge, TN 37831-6038
   Tel: 865-574-7314
   Fax: 865-576-8646
   Email: tangg@ornl.gov


Please contact tangg@ornl.gov to report bugs, and for technical support.

References: 
Tang, G., Watson, D. B., Parker, J. C., and Scott C. Brooks, 2011. A Spreadsheet program for two-well tracer test data analysis. Ground Water. DOI: 10.1111/j.1745-6584.2011.00841.x. 

Tang, G., Mayes, M. A., Parker, J. C., and Jardine, P. M. 2010. CXTFIT/Excel-a modular adaptable code for parameter estimation, sensitivity analysis and uncertainty analysis for laboratory and field tracer experiments. Computers & Geosciences. 36(9), 1200-1209, DOI:10.1016/j.cageo.2010.01.013. 